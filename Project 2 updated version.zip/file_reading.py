"""
CSC111 Project 2 File Reading Compatibility Module

This module re-exports the UI file reading helpers from the project root so
other modules can import them without depending on a package-relative path.

Copyright and Usage Information
===============================

This file is provided solely for the personal and private use of the group by
Yara Megahed in CSC111 project 2 at the University of Toronto St. George
campus. All forms of distribution of this code, whether as given or with any
changes, are expressly prohibited.

This file is Copyright 2026 CSC111 Project 2 Group Yara Megahed, Levi Pan,
Haoxuan Shen, Laien Zou.
"""

from UI.file_reading import clean_up_line, read_file

__all__ = ['read_file', 'clean_up_line']


if __name__ == '__main__':
    import doctest
    import python_ta

    doctest.testmod()

    python_ta.check_all(config={
        'max-line-length': 120,
        'disable': ['static_type_checker'],
        'extra-imports': ['UI.file_reading'],
        'allowed-io': []
    })
