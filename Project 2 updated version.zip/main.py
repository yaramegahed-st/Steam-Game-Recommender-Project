"""
CSC111 Project 2 main.py
This file launches the Steam game recommender system by loading the datasets,
building the graph, and opening the user interface.

Copyright and Usage Information
===============================

This file is provided solely for the personal and private use of the group by Yara Megahed
in CSC111 project 2 at the University of Toronto St. George campus. All forms of
distribution of this code, whether as given or with any changes, are expressly prohibited.

This file is Copyright 2026 CSC111 Project 2 Group Yara Megahed,Levi Pan,Haoxuan Shen, Laien Zou.
"""

from __future__ import annotations

import game_user_graph
from UI.ui3 import Interface


def run_program() -> None:
    """Load the datasets, build the graph, and launch the interface."""
    game_data = game_user_graph.load_game_data('Data/filtered_steam_data_4000.csv')
    user_data = game_user_graph.load_user_data('Data/sample_user_data_4000.csv')
    graph = game_user_graph.load_game_user_graph(game_data, user_data)

    Interface(graph, 'Data/filtered_steam_data_4000.csv')


if __name__ == '__main__':
    run_program()
